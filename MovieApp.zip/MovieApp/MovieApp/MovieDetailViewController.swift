//
//  MovieDetailViewController.swift
//  MovieApp
//
//  Created by Jatin Kumar on 2024-08-15.
//

import UIKit
import CoreData

class MovieDetailViewController: UIViewController {

    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var overviewLabel: UITextView!
    @IBOutlet weak var saveButton: UIButton!

    var movie: Movie?

    override func viewDidLoad() {
        super.viewDidLoad()
        displayMovieDetails()
    }

    func displayMovieDetails() {
        guard let movie = movie else { return }
        titleLabel.text = movie.title
        releaseDateLabel.text = "Release Date: \(movie.releaseDate)"
        overviewLabel.text = movie.overview
        
        if let posterPath = movie.posterPath {
            if let posterURL = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)") {
                URLSession.shared.dataTask(with: posterURL) { data, response, error in
                    if let data = data {
                        DispatchQueue.main.async {
                            self.posterImageView.image = UIImage(data: data)
                        }
                    }
                }.resume()
            }
        } else {
            posterImageView.image = UIImage(named: "placeholder_image")
        }
    }

    @IBAction func saveButtonTapped(_ sender: UIButton) {
        saveMovieToCoreData()
    }

    func saveMovieToCoreData() {
        guard let movie = movie else { return }

        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext

        // Check if the movie is already saved
        let fetchRequest: NSFetchRequest<MovieModel> = MovieModel.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %d", movie.id)

        do {
            let results = try context.fetch(fetchRequest)
            if results.count > 0 {
                // Movie already exists in Core Data
                let alert = UIAlertController(title: "Duplicate Movie", message: "This movie is already saved in your favorites.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                present(alert, animated: true, completion: nil)
                return
            }

            // If not already saved, save the movie
            let savedMovie = MovieModel(context: context)
            savedMovie.id = Int64(movie.id)
            savedMovie.title = movie.title
            savedMovie.overview = movie.overview
            savedMovie.posterPath = movie.posterPath
            savedMovie.releaseDate = movie.releaseDate
            savedMovie.voteAverage = movie.voteAverage
            savedMovie.voteCount = Int64(movie.voteCount)

            try context.save()
            print("Movie saved successfully!")
            let alert = UIAlertController(title: "Success", message: "Movie saved to favorites.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)

        } catch {
            print("Failed to save movie: \(error)")
            let alert = UIAlertController(title: "Error", message: "Failed to save movie.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
    }
}
