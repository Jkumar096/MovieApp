//
//  MovieListViewController.swift
//  MovieApp
//
//  Created by Jatin Kumar on 2024-08-15.
//

import UIKit

class MovieListViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!

    var movies: [Movie] = []
        var searchTimer: Timer?

        override func viewDidLoad() {
            super.viewDidLoad()
            tableView.delegate = self
            tableView.dataSource = self
            searchBar.delegate = self
            
            fetchMovies(query: "popular")
        }

        func fetchMovies(query: String) {
            let apiKey = "158e8cecbd5bf80a9f0c081944a78a90"
            let urlString = "https://api.themoviedb.org/3/search/movie?api_key=\(apiKey)&query=\(query)"
            guard let url = URL(string: urlString) else { return }

            URLSession.shared.dataTask(with: url) { data, response, error in
                guard let data = data, error == nil else {
                    print("Error fetching data")
                    return
                }
                do {
                    let decoder = JSONDecoder()
                    if let jsonObject = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                       let results = jsonObject["results"] as? [[String: Any]] {
                        let jsonData = try JSONSerialization.data(withJSONObject: results, options: [])
                        self.movies = try decoder.decode([Movie].self, from: jsonData)
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                    } else {
                        print("Unexpected JSON structure")
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            }.resume()
        }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showSavedMovies" {
            // Additional configuration can be added here if needed
        } else if segue.identifier == "showMovieDetail",
                  let destinationVC = segue.destination as? MovieDetailViewController,
                  let selectedIndex = tableView.indexPathForSelectedRow?.row {
            destinationVC.movie = movies[selectedIndex]
        }
    }

    @IBAction func savedMoviesButtonTapped(_ sender: UIBarButtonItem) {
        performSegue(withIdentifier: "showSavedMovies", sender: self)
    }

    }

    // Extension to handle TableView DataSource and Delegate
    extension MovieListViewController: UITableViewDelegate, UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return movies.count
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "movieCell", for: indexPath)
            let movie = movies[indexPath.row]
            cell.textLabel?.text = movie.title
            cell.detailTextLabel?.text = "Rating: \(movie.voteAverage) (\(movie.voteCount) votes)"
            
            if let posterPath = movie.posterPath {
                if let posterURL = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)") {
                    URLSession.shared.dataTask(with: posterURL) { data, response, error in
                        if let data = data {
                            DispatchQueue.main.async {
                                cell.imageView?.image = UIImage(data: data)
                                cell.setNeedsLayout() // Refresh the layout to display the image
                            }
                        }
                    }.resume()
                }
            } else {
                // Handle the case where posterPath is nil (e.g., set a placeholder image)
                cell.imageView?.image = UIImage(named: "placeholder_image")
            }
            
            return cell
        }
    }

    // Extension to handle SearchBar Delegate
    extension MovieListViewController: UISearchBarDelegate {
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            // Cancel any existing timer
            searchTimer?.invalidate()
            
            // Debounce the search request to avoid excessive API calls
            if !searchText.isEmpty {
                searchTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] _ in
                    self?.fetchMovies(query: searchText)
                }
            } else {
                self.movies.removeAll()
                self.tableView.reloadData()
            }
        }

        func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
            searchBar.resignFirstResponder() // Dismiss the keyboard when the search button is clicked
        }
    }

    // Models for decoding JSON when there's a "results" array
    struct MovieResponse: Codable {
        let results: [Movie]
    }

    struct Movie: Codable {
        let id: Int
        let title: String
        let overview: String
        let posterPath: String?
        let releaseDate: String
        let voteAverage: Double
        let voteCount: Int

        enum CodingKeys: String, CodingKey {
            case id
            case title
            case overview
            case posterPath = "poster_path"
            case releaseDate = "release_date"
            case voteAverage = "vote_average"
            case voteCount = "vote_count"
        }
    }


