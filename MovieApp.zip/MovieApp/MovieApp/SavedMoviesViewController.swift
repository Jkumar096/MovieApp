//
//  SavedMoviesViewController.swift
//  MovieApp
//
//  Created by Jatin Kumar on 2024-08-15.
//

import UIKit
import CoreData

class SavedMoviesViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!

    var savedMovies: [MovieModel] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        fetchSavedMovies()
    }

    func fetchSavedMovies() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<MovieModel> = MovieModel.fetchRequest()

        do {
            savedMovies = try context.fetch(fetchRequest)
            tableView.reloadData()
        } catch {
            print("Failed to fetch saved movies: \(error)")
        }
    }
}

extension SavedMoviesViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return savedMovies.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "savedMovieCell", for: indexPath)
        let savedMovie = savedMovies[indexPath.row]
        cell.textLabel?.text = savedMovie.title
        cell.detailTextLabel?.text = "Rating: \(savedMovie.voteAverage) (\(savedMovie.voteCount) votes)"
        
        if let posterPath = savedMovie.posterPath {
            if let posterURL = URL(string: "https://image.tmdb.org/t/p/w500\(posterPath)") {
                URLSession.shared.dataTask(with: posterURL) { data, response, error in
                    if let data = data {
                        DispatchQueue.main.async {
                            cell.imageView?.image = UIImage(data: data)
                            cell.setNeedsLayout() // Refresh the layout to display the image
                        }
                    }
                }.resume()
            }
        } else {
            // Handle the case where posterPath is nil (e.g., set a placeholder image)
            cell.imageView?.image = UIImage(named: "placeholder_image")
        }
        
        return cell
    }

    // Optional: Implement a method to delete saved movies
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let movieToDelete = savedMovies[indexPath.row]
            deleteMovie(movie: movieToDelete)
            savedMovies.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }

    func deleteMovie(movie: MovieModel) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        context.delete(movie)
        
        do {
            try context.save()
        } catch {
            print("Failed to delete movie: \(error)")
        }
    }
}
