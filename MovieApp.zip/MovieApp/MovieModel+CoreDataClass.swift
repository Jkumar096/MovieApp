//
//  MovieModel+CoreDataClass.swift
//  MovieApp
//
//  Created by Jatin Kumar on 2024-08-15.
//
//

import Foundation
import CoreData

@objc(MovieModel)
public class MovieModel: NSManagedObject {

}
